using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace HttpClientPortable.Core
{
	public static class MyClass
	{
		public static async Task<string> DoStuff ()
		{
			var client = new HttpClient ();
			var result = await client.GetAsync ("http://twincoders.com");
			return result.ToString();
		}
	}
}

